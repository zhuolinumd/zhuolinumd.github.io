% clc - clear command window.
%
% USAGE
%  c
%
% INPUTS
%
% OUTPUTS
%
% EXAMPLE
%
% See also CLC, CC, CCC
%
% Piotr's Image&Video Toolbox      Version 1.5
% Copyright 2008 Piotr Dollar.  [pdollar-at-caltech.edu]
% Please email me if you find bugs, or have suggestions or questions!
% Licensed under the Lesser GPL [see external/lgpl.txt]

clc
