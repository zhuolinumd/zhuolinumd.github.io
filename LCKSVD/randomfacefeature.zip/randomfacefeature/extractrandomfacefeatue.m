%%% an example of extracting random face feature descriptors
%%%
% parameter setting
dims = 504; % dimension of random-face feature descriptor
IMG_H = 192; % input image size
IMG_W = 168;

% generate the random matrix
randmatrix = randn(dims,IMG_H*IMG_W);
l2norms = sqrt(sum(randmatrix.*randmatrix,2)+eps);
randmatrix = randmatrix./repmat(l2norms,1,size(randmatrix,2));


% Note that you should use the same randmatrix 
% when you iterate all the input images and extract descriptors
img = imread('img1071.png');
feature = double(img(:));
randomfacefeature = randmatrix*feature;